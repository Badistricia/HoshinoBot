## 一个简单的hoshino疯狂星期四插件

## 安装

1. 在`HoshinoBot/hoshino/modules`目录clone本项目 
```
git clone https://github.com/Nicr0n/fucking_crazy_thursday.git
```
1. 在`HoshinoBot/hoshino/config/__bot__.py`文件的`MODULES_ON`里添加`fucking_crazy_thursday`
1. 重启hoshino

## 指令
|  指令   | 说明  |
|  ----  | ----  |
| 来点疯狂星期四文案\|疯狂星期四 |随机从json中抽取一条疯狂星期四文案 |

## 后续计划

1. 制作网页版疯狂星期四，通过API接口获取文案❎
